﻿using System;
using System.Collections.Generic;
using System.Text;

namespace thicau2
{
    interface ITable
    {
       public void ShowInfo() 
        {
          

        }
        public void Pay( )
        {
         
         
        }

   
    }
}
