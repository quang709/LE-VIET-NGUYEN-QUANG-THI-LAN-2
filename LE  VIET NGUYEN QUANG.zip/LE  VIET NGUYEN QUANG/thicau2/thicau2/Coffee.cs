﻿using System;
using System.Collections.Generic;
using System.Text;
namespace thicau2
{
    class Coffee
    {
        int count = 0;
        Dictionary<int, Table> tCoffee = new Dictionary<int, Table>();
        public void NewOrder()
        {
            Table table = new Table();
            table.TableId = count;
            Console.WriteLine("Start Time: ");
            table.StartTime = DateTime.Parse(Console.ReadLine());
            Console.WriteLine("End Time: ");
            table.EndTime = DateTime.Parse(Console.ReadLine());
            Console.WriteLine("-------------------");

         
            

            tCoffee.Add(count, table);
        }
      
        public void CancelOrder()
        {
            Console.WriteLine("Please enter a table ID you want to delete: ");
            int n = Int32.Parse(Console.ReadLine());
            foreach (var item in tCoffee.Values)
                if (n.Equals(item.TableId))
                {
                    tCoffee.Remove(n);
                    Console.WriteLine("Removed Success!!");
                    break;
                }
                else Console.WriteLine("Not Found!!");
        }
        public void Search()
        {
            Table table = new Table();
            bool search = false;
            Console.WriteLine("Please enter a table ID: ");
            int n = Int32.Parse(Console.ReadLine());
            foreach (var item in tCoffee.Values)
            {
                if (n.Equals(item.TableId))
                {
                    search = true;
                    table.ShowInfo();
                }
                if (search == false)
                    Console.WriteLine("NOt Fount.");
            }
        }

        public void UpdateOrder()
        {

        }
        public void Pay()
        {

        }
        public void Show()
        {
            foreach (var item in tCoffee.Values)
            {
                item.ShowInfo();
            }
        }
    }
}

