﻿using System;
using System.Collections.Generic;
using System.Text;

namespace thicau2
{
    public class Table : ITable
    {
        public int TableId { get; set; }
        public DateTime StartTime { get; set; }
        public DateTime EndTime { get; set; }
        public long SumTotal { get; set; }
        public List<OrderDetail> orderDetails { get; set; }

        public void ShowInfo(int TableId, DateTime StartTime, DateTime EndTime, long SumTotal, List<OrderDetail> OrderDetails)
        {
            Console.WriteLine($" TableId {TableId} StartTime:{StartTime} EndTime:{EndTime}SumTotal:{SumTotal} OrderDetails:{OrderDetails}");

        }
        public void Pay(int TableId, DateTime StartTime, DateTime EndTime, long SumTotal, List<OrderDetail> OrderDetails, int Total)
        {
            foreach (OrderDetail item in OrderDetails) 
             SumTotal =+ item.Total;
          
        }

        internal void ShowInfo()
        {
          
        }
    }
}
