﻿using System;
using System.Collections.Generic;
using System.Text;

namespace thicau2
{
  public  class OrderDetail
    {



        public string Name { get; set; }
        public long Price { get; set; }
        public int Count { get; set; }
        public long Total { get; set; }
        public int TableId { get; internal set; }

        public void CalculatorTotal( string Name, long   Price, int Count , long Total)
        {
            Total = (Price * Count); 
        }
        public void Show(string Name, long Price, int Count, long Total)
        {
            Console.WriteLine($" san pham:{Name} gia:{Price}so luong:{Count} tong:{Total}");
        }
    }
}
