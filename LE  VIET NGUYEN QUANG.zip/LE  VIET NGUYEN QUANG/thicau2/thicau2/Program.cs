﻿using System;
using System.Collections;
using System.Text;

namespace thicau2
{
    class Program
    {
      static void Main(string[] args)
        {
            Coffee coffee = new Coffee();
            Table table = new Table();
            int choice;
            do
            {
                Console.WriteLine("1. New Order");
                Console.WriteLine("2. Update Order");
                Console.WriteLine("3. Cancel Order");
                Console.WriteLine("4. Search");
                Console.WriteLine("5. Pay");
                Console.WriteLine("6. Exit");

                Console.WriteLine(" Select: ");
                choice = Int32.Parse(Console.ReadLine());
                switch (choice)
                {
                    case 1:
                        Console.WriteLine("nhap table ID:");
                        int n = Int32.Parse(Console.ReadLine());
                        if (n == table.TableId)
                        {
                            Console.WriteLine("table is using");
                        }
                        else
                        Console.WriteLine("name:");
                        OrderDetail.Name = Console.ReadLine();
                        Console.WriteLine("Price:");

                        Console.WriteLine("Total:");

                        coffee.NewOrder();
                        table.ShowInfo();
                       
                        break;
                    case 2:
                        coffee.UpdateOrder();
                        break;
                    case 3:
                        coffee.CancelOrder();
                        break;
                    case 4:
                        coffee.Search();
                        break;
                    case 5:
                        coffee.Pay();
                        break;
                    case 6: return;
                }
            }
            while (choice != 6);
        }
    }
}
